# @jeremydavidson/releasekit

Unified **local** release toolkit: bump semver, stamp version files, run deploy hooks, then commit / tag / push.

MIT licensed. Publish-ready npm package (same layout family as `setup-monitoring` in this repo).

## Install

```bash
yarn add -D @jeremydavidson/releasekit
# or
npm i -D @jeremydavidson/releasekit
```

### Local link (before first publish)

From this package:

```bash
cd releasekit
yarn
yarn build
yarn link
```

In a consumer repo:

```bash
yarn link @jeremydavidson/releasekit
```

Or add a file dependency without linking:

```json
{
  "devDependencies": {
    "@jeremydavidson/releasekit": "file:../scripts/releasekit"
  }
}
```

## CLI

```bash
npx releasekit release              # bump → stamp → gate? → deploy[] → verify? → git
npx releasekit release --channel dev --bump patch -y
npx releasekit release --aws --vercel   # unknown --flags become deploy `when.flag` matches
npx releasekit sync                 # stamp-only from current package.json (no bump/git)
npx releasekit status               # one-line: in-sync | need-rel+N | need-rel+N↑M
npx releasekit status --json
```

Wire scripts in the product `package.json`:

```json
{
  "scripts": {
    "release": "releasekit release",
    "release:dev": "releasekit release --channel dev",
    "sync-version": "releasekit sync"
  }
}
```

## Config schema

Look for (in order): `release.config.ts` / `.mts` / `.js` / `.mjs` / `.cjs` / `.json` in the cwd.

```ts
// release.config.ts
export default {
  versionStyle: {
    padPatch: false,       // Sprig family: true → 1.0.019
    prerelease: "beta",    // "none" | "beta"
  },
  stamp: [
    { type: "packageJson", path: "package.json" },
    { type: "tsConst", path: "packages/env/src/app-version.ts", exportName: "APP_VERSION" },
    { type: "versionJson", path: "frontend/public/version.json" },
    { type: "expoAppJson", path: "app.json", bumpNativeCounters: false },
  ],
  channels: {
    prod: { branch: ["main", "master"], prerelease: false },
    dev: { prerelease: true },
  },
  qualityGate: "yarn lint",
  deploy: [
    { id: "aws", command: "yarn deploy:infra:app", when: { flag: "aws", channel: "prod" } },
    { id: "shopify", command: "yarn shopify:deploy" },
  ],
  verify: "curl -sf https://example.com/version",
  git: {
    commitTemplate: "chore: release {version}",  // or "chore: released {version}"
    tagTemplate: "v{version}",
    rollbackOnDeployFailure: true,
    extraPaths: [],
    remote: "origin",
  },
  // packageJsonPath: "package.json",
}
```

See `release.config.example.ts` in this package.

### Stamp targets

| type | writes |
|------|--------|
| `packageJson` | `version` field |
| `tsConst` | `export const APP_VERSION = "…"` (or `exportName`) |
| `versionJson` | JSON key (default `version`) |
| `expoAppJson` | `expo.version`; optional iOS/Android counter bump |

### Pipeline phases

`bump → stamp → qualityGate? → deploy[] → verify? → git`

Deploy hooks with `when.flag` only run when that CLI flag is present (`--aws`, `--vercel`, …). Hooks with `when.channel` only run for matching channels.

On deploy failure with `rollbackOnDeployFailure: true`, stamped files are restored from snapshots.

## Multi-project / workspace mode

For parents like `limetry-workspace/` that orchestrate child checkouts:

```ts
export default {
  versionStyle: { padPatch: false, prerelease: "beta" },
  projects: [
    {
      id: "core",
      cwd: "limetry",
      stamp: [
        { type: "packageJson", path: "package.json" },
        { type: "tsConst", path: "packages/sdk/src/app-version.ts" },
      ],
    },
    {
      id: "enterprise",
      cwd: "limetry-enterprise",
      stamp: [{ type: "packageJson", path: "package.json" }],
      deploy: [{ id: "pulumi", command: "yarn deploy:infra", when: { flag: "aws" } }],
    },
  ],
  git: {
    commitTemplate: "chore: release {version}",
    tagTemplate: "v{version}",
  },
}
```

`stacks` is an alias for `projects`. Each child gets its own stamp / optional qualityGate / deploy / verify / git cwd. Schema bumps and peer planners stay as **child hook commands**, not hard-coded core logic.

Keep a single-stack path on public OSS children so contributors without the sibling can still release.

## zsh release prompt

Ship `shell/release-prompt.zsh` plus a ready-to-paste snippet at
[`docs/zshrc-snippet.zsh`](./docs/zshrc-snippet.zsh). **Copy the snippet into
`~/.zshrc`** — do not overwrite the whole file.

```zsh
# See docs/zshrc-snippet.zsh for the full helper.
releasekit_prompt() {
  root=$(git rev-parse --show-toplevel 2>/dev/null) || return
  for candidate in \
    "$root/node_modules/@jeremydavidson/releasekit/shell/release-prompt.zsh" \
    "$root/scripts/release-prompt.zsh"
  do
    [[ -f "$candidate" ]] || continue
    source "$candidate"
    _releasekit_do_release_prompt "$root"
    return
  done
}
RPROMPT='$(releasekit_prompt)'
```

Detection looks for `release.config.*`, a `package.json` dependency on releasekit, or legacy `scripts/sync-version.ts` / `scripts/release.ts`. Last release is `v*` tags, else commits matching `chore: release ` **or** `chore: released `.

Or use the CLI: `releasekit status` (same semantics as a one-liner).

### Safety notes (git)

- Detached HEAD is refused (no silent `main` fallback).
- Release commits use an explicit pathspec so unrelated staged files stay out.
- Conflicting tags (same name, different commit) fail fast.
- Branch and tag are pushed separately; partial push triggers remote + local rollback when enabled.
- Local rollback uses `git reset --mixed` (not `--hard`) and the configured `tagTemplate`.
- Dirty worktrees refuse a full release unless `--allow-dirty` or `--skip-git`.
- `releasekit sync` (stamp-only) skips channel/branch gates.

## Migration guide

1. **Add the dependency** (registry or `file:` / `yarn link`).
2. **Add `release.config.ts`** mapping your old hardcoded paths/commands (start from `release.config.example.ts`).
3. **Keep a thin shim** so existing scripts keep working:

```ts
// scripts/sync-version.ts — temporary shim
import { spawnSync } from "node:child_process"
const args = process.argv.slice(2)
const stampOnly = args.includes("--sync-only") || args.includes("--stamp-only")
spawnSync(
  "npx",
  ["releasekit", stampOnly ? "sync" : "release", ...args],
  { stdio: "inherit" },
)
```

4. **Port tests**: keep calling your old helpers until golden parity, then delete local `release-version.ts`.
5. **Preserve quirks via config**: `padPatch`, commit template (`release` vs `released`), deploy `when` flags, rollback defaults.
6. **Do not big-bang** every repo — pilot one (e.g. sprig-sales-ce), then Sprig family, then gatebooker/disruptdev-em, then limetry-workspace.

Out of scope for v1: setupenv merge, Limetry peer planner inside core, vendoring sync tool.

## Library API

```ts
import {
  computeNextVersion,
  parseReleaseConfig,
  runPipeline,
  stampAll,
  getReleaseStatus,
} from "@jeremydavidson/releasekit"
```

## Develop

```bash
cd releasekit
yarn
yarn test
yarn build
```

`prepublishOnly` runs `yarn build`. Published `files`: `dist`, `shell`.

## License

MIT
