# releasekit zsh RPROMPT helper (generalized from sprig-sales-ce).
# - [need-rel+N] / [need-rel+N↑M] when commits exist since the last release
# - [in-sync...] when HEAD is at the last release tag
#
# Emits literal %F{...}%f sequences (print -rn, not -P) so zsh prompt_subst
# colors them with correct visible width (flush right).
#
# Detection: release.config.* OR package.json mentioning releasekit OR
# legacy scripts/sync-version.ts / scripts/release.ts.
#
# Usage in ~/.zshrc:
#
#   releasekit_prompt() {
#     root=$(git rev-parse --show-toplevel 2>/dev/null) || return
#     # Prefer package-shipped prompt when linked/installed:
#     for candidate in \
#       "$root/node_modules/@jeremydavidson/releasekit/shell/release-prompt.zsh" \
#       "$root/scripts/release-prompt.zsh" \
#       "$root/release-prompt.zsh"
#     do
#       [[ -f "$candidate" ]] || continue
#       source "$candidate"
#       _releasekit_do_release_prompt "$root"
#       return
#     done
#   }
#   RPROMPT='$(releasekit_prompt)'

_releasekit_repo_uses_release() {
  local root=$1
  [[ -f "$root/release.config.ts" \
     || -f "$root/release.config.mts" \
     || -f "$root/release.config.js" \
     || -f "$root/release.config.mjs" \
     || -f "$root/release.config.cjs" \
     || -f "$root/release.config.json" ]] && return 0

  if [[ -f "$root/package.json" ]] && grep -qE '"(@jeremydavidson/releasekit|releasekit)"' "$root/package.json" 2>/dev/null; then
    return 0
  fi

  # Legacy Sprig / gatebooker markers
  [[ -f "$root/scripts/sync-version.ts" || -f "$root/scripts/release.ts" ]] && return 0
  return 1
}

_releasekit_do_release_prompt() {
  local root=$1
  local last count unpushed

  _releasekit_repo_uses_release "$root" || return

  last=$(git -C "$root" describe --tags --abbrev=0 --match 'v[0-9]*' 2>/dev/null)
  if [[ -z "$last" ]]; then
    last=$(git -C "$root" log -1 --format=%H --grep='^chore: release ' 2>/dev/null)
  fi
  if [[ -z "$last" ]]; then
    last=$(git -C "$root" log -1 --format=%H --grep='^chore: released ' 2>/dev/null)
  fi
  if [[ -z "$last" ]]; then
    return
  fi

  count=$(git -C "$root" rev-list --count "${last}..HEAD" 2>/dev/null)
  if [[ -z "$count" || "$count" -eq 0 ]]; then
    print -rn -- "%F{108}[in-sync...]%f"
    return
  fi

  unpushed=$(git -C "$root" rev-list --count '@{u}..HEAD' 2>/dev/null)
  if [[ -n "$unpushed" && "$unpushed" -gt 0 ]]; then
    print -rn -- "%F{214}[need-rel+${count}↑${unpushed}]%f"
  else
    print -rn -- "%F{214}[need-rel+${count}]%f"
  fi
}

# Back-compat alias for existing Sprig zshrc snippets
_sprig_do_release_prompt() {
  _releasekit_do_release_prompt "$@"
}
