# releasekit zsh RPROMPT snippet — paste into ~/.zshrc (do not replace the whole file).
# Package path after yarn/npm install or file: link:
#   node_modules/@jeremydavidson/releasekit/shell/release-prompt.zsh

releasekit_prompt() {
  root=$(git rev-parse --show-toplevel 2>/dev/null) || return
  for candidate in \
    "$root/node_modules/@jeremydavidson/releasekit/shell/release-prompt.zsh" \
    "$root/scripts/release-prompt.zsh" \
    "$root/release-prompt.zsh"
  do
    [[ -f "$candidate" ]] || continue
    source "$candidate"
    _releasekit_do_release_prompt "$root"
    return
  done
}

# Optional: keep any existing RPROMPT content and append.
# RPROMPT='$(releasekit_prompt)'
# Or: RPROMPT="${RPROMPT:+$RPROMPT }"'$(releasekit_prompt)'
